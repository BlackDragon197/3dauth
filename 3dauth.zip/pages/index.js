import Layout from "../components/Layout";
import Link from "next/link";
import { authInitialProps } from "../lib/auth";
import Head from 'next/head'
import styled from 'styled-components'
import Navbar from '../components/Navbar'
import InBlock2 from '../components/InBlock2.jsx'
import InBlock3 from '../components/InBlock3.jsx'
import InBlock4 from '../components/InBlock4.jsx'
import InBlock5 from '../components/InBlock5.jsx'
import InBlock6 from '../components/InBlock6.jsx'
import InBlock7 from '../components/InBlock7.jsx'

const Title = styled.h1`
  color: red;
  font-family: Gilroy;
`

const Group = styled.div`
    display: flex;
    margin-top: ${props => props.top};
    left: ${props => props.left};
    width: ${props => props.width};
    height: ${props => props.height};
    position: relative;
    align-items: center;
`

const AddBtn = styled.a`

width: ${props => props.width};
height: 2.8em;
font-family: Gilroy;
font-style: normal;
font-weight: 600;
font-size: 0.938vw;
line-height: 1.054vw;
color: #FFFFFF;
display: flex;
justify-content: center;
align-items: center;
box-sizing: border-box;
border-radius: 6px;
position: relative;
cursor: pointer;
filter: drop-shadow(0px 4px 4px rgba(0, 0, 0, 0.25));
transition: 500ms;
left: ${props => props.left};
background: ${props => props.background};
`

export default function Index(props){
    return(
        <div>
        <div style={{height:'76.2%',display:'', background: '#F7F8FB', backgroundPosition: 'top right', backgroundImage:'url(/static/wrapperbg.png)', backgroundRepeat:'no-repeat', backgroundSize:'75%'}}>
          <Head>
            <title>Pegas Capital Main</title>
          </Head>
          <Navbar />
          <div className="container" style={{ height:'48vh',backgroundPosition: 'bottom right, top right 18%', backgroundImage:'url(/static/profit.png), url(/static/coin.png)', backgroundRepeat:'no-repeat', backgroundSize:'44%, 17%'}}>
          <Group top="12vh" left="12.240vw" width="46.61vw" height="54.427vh">
            <div style={{height: '8vw', width: '100%', top:'0', position:'absolute', textAlign:'left'}}>
                <span style={{fontWeight:'700', fontStyle:'normal', fontFamily:'Gilroy', lineHeight:'140%', fontSize:'2.344vw', textTransform: 'uppercase', color:'#15274E'}}>
                Инвестируйте вместе с Pegas Capital и гарантировано <span style={{fontWeight:'800', color:'#0E6AE0'}}>зарабатывайте <br />до 15% ежемесячной комиссии</span>
                </span>
                
            </div>
            <div style={{height: '8vw', width: '61.994%', top:'9vw', position:'absolute', textAlign:'left', display:'flex', alignItems:'center'}}>
            <span style={{fontWeight:'500', fontStyle:'normal', fontFamily:'Gilroy', lineHeight:'140%', fontSize:'1.302vw', color:'#15274E'}}>
            Выбирайте 1 из 3 инвестиционных программ<br/><span style={{fontWeight:'600', fontStyle:'normal',color:'#15274E'}}>и приумножайте свой капитал</span>
                </span>
            </div>
        <AddBtn width="12.719vw" background="#0085FF" left="12.240vw" style={{position:'absolute', top:'17vw', left:'0'}}>Получить консультацию                    
                       
        </AddBtn>
        <AddBtn  width="16.667vw" background="#15274E" left="14.240vw" style={{position:'absolute', top:'17vw'}}>Программы сотрудничества                    
                       
        </AddBtn>
        {/*<Image src='/static/coin.png' width='470px' height='500px' style={{position:'absolute', top:'0'}}/>*/}
        </Group>
        </div>
    
    </div>
    <InBlock2 />
    <InBlock3 />
    <InBlock4/>
    <div style={{height: '16.53vh'}}></div>
    <InBlock5 />
    <InBlock6 />
    {/* <InBlock7 /> */}
    </div>


    )

}


Index.getInitialProps = authInitialProps();
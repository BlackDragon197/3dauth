import * as React from "react";

class ReferalComponent extends React.Component {
    render() {
      return (<div><h3>Ваши рефералы:</h3><br /><br /><br />
      <h4>Не найдено :(</h4></div>);
    }
  }
  export default ReferalComponent
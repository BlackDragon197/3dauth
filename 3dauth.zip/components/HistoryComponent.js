import * as React from "react";

class HistoryComponent extends React.Component {
    render() {
      return (<div><h3>История платежей:</h3><br /><br /><br />
        <h4>История пуста :(</h4></div>);
    }
  }
  export default HistoryComponent
import styled from 'styled-components'
import Image from 'next/image'
import Heading from '../components/Heading4.jsx'

const Container = styled.div`
//width: 100%;
max-width: 1200px;
display: flex;
align-items: center;
justify-content: center;
height: 900px;
`

const Column = styled.div`
display: flex;
flex-direction: column;
flex: 2;
`

const Columna = styled.div`
display: flex;
flex-direction: column;
flex: 7;
`

export default function Block(){
    
    return (
        <Container> 
            <Column></Column>
            <Columna>
                <h1>Наши цели на 2022</h1>
                <div>
                    <p>
                        В 2022 году компания Pegas Capital планирует запустить масштабное ICO, которое позволит всем нашим клиентам без дополнительных вложений получить электронную валюту, которую сможет обменять на реальные деньги.
                    </p>
                    <p>
                        В 2023 году компания планирует запустить собственную платежную систему 
                    </p>
                    <p>
                        В 2024 году компания планирует запустить собственную криптобиржу
                    </p>
                    <p>
                        В 2025 году компания планирует создать первый в России банк с поддержкой криптовалюты
                    </p>
                </div>
            </Columna>
            <Column>
            </Column>
            <Column>
            </Column>
        </Container>

    )
}
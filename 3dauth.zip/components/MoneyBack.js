import * as React from "react";

class HistoryComponent extends React.Component {
    render() {
      return (<div><h3>Заказать выплату</h3><br /><br /><br />
        <h4>Доступно для выплаты:</h4>
        <h3>0.00</h3></div>);
    }
  }
  export default HistoryComponent